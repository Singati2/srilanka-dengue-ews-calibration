#!/usr/bin/env python3
"""
Main Figure 1 (V31): real analytic-frame + coverage maps (A, B) + timelines (C) + flow (D).
A: Sri Lanka 26 RDHS units (rdhs_26_v1.gpkg).  B: Colombia coverage/selection
(GADM v4.1 admin-2 x common-complete flag).  C: study timelines.  D: analysis flow.
All numbers from committed data/geometry (no fabrication). Writes submission_figs/Fig1.pdf.
"""
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd, geopandas as g
from matplotlib.patches import FancyBboxPatch, Rectangle, Patch

RDHS="/home/mpcrlab/data_quarantine/geomatics/rdhs_geometry/rdhs_26_v1.gpkg"
MT="/home/mpcrlab/data_quarantine/colombia_label_features_v1/colombia_modeling_table_h4_75pct_v1.csv"
GADM="/home/mpcrlab/data_quarantine/colombia_external_replication_feasibility_v1/gadm41_COL_2.json.zip"
BLUE=("#cfe2f3","#5b8fc9"); TAN=("#fce5cd","#e69138"); GREEN=("#d9ead3","#6aa84f")
PINK=("#ead1dc","#c27ba0"); GREY=("#eeeeee","#8a8a8a"); INK="#333333"

fig=plt.figure(figsize=(9.6,8.4))
axA=fig.add_subplot(2,2,1); axB=fig.add_subplot(2,2,2)
axC=fig.add_subplot(2,2,3); axD=fig.add_subplot(2,2,4)

# ---------- A: Sri Lanka RDHS ----------
sl=g.read_file(RDHS).to_crs(32644)
sl.plot(ax=axA,facecolor=BLUE[0],edgecolor=BLUE[1],linewidth=0.5)
amp=sl[sl['rdhs_name'].str.contains("Ampara|Kalmunai",case=False,na=False)]
if len(amp): amp.plot(ax=axA,facecolor=TAN[0],edgecolor=TAN[1],linewidth=0.8)
axA.set_axis_off(); axA.set_title("A  Sri Lanka: 26 RDHS analytic units",loc="left",fontsize=10,fontweight="bold")
axA.annotate("Ampara/Kalmunai split highlighted. Boundaries: HDX COD-AB. RDHS = bootstrap cluster. EPSG:32644.",
             xy=(0.5,-0.02),xycoords="axes fraction",ha="center",va="top",fontsize=5.4,color="#555")

# ---------- B: Colombia coverage/selection ----------
d=pd.read_csv(MT,dtype={'week_start':str}); d['yr']=d['week_start'].str[:4].astype(int)
te=d[(d.yr>=2020)&(d.yr<=2022)]; inc=set(te[te['common_complete_M1_to_M5_h4']==True].GID_2)
obs=set(te.GID_2); excl=obs-inc
gd=g.read_file(f"zip://{GADM}")
gid='GID_2' if 'GID_2' in gd.columns else [c for c in gd.columns if c.upper()=='GID_2'][0]
def cls(x): return 'Included (common-complete)' if x in inc else ('Observed but excluded' if x in excl else 'No usable test-period data')
gd['cls']=gd[gid].map(cls); gd=gd.to_crs(3116)
CM={'Included (common-complete)':'#0072B2','Observed but excluded':'#999999','No usable test-period data':'#f0f0f0'}
for k,c in CM.items():
    sub=gd[gd.cls==k]
    if len(sub): sub.plot(ax=axB,facecolor=c,edgecolor='white',linewidth=0.04)
gd['dept']=gd[gid].str.split('.').str[1]; gd.dissolve('dept').boundary.plot(ax=axB,color='#444',linewidth=0.25)
axB.set_axis_off(); axB.set_title("B  Colombia: coverage and selection (test 2020–22)",loc="left",fontsize=10,fontweight="bold")
axB.legend(handles=[Patch(facecolor=CM[k],edgecolor='#888',label=f"{k} (n={sum(gd.cls==k)})") for k in CM],
           loc="lower left",fontsize=5.6,frameon=False)
axB.annotate("GADM v4.1 admin-2; department outlines dissolved from GID_1. EPSG:3116. Included = 475 of 864; inference not national.",
             xy=(0.5,-0.02),xycoords="axes fraction",ha="center",va="top",fontsize=5.0,color="#555")

# ---------- C: timelines ----------
axC.set_title("C  Study timelines",loc="left",fontsize=10,fontweight="bold")
axC.set_xlim(2005.5,2025.8); axC.set_ylim(0,3); axC.axis("off")
for yr in range(2006,2026,3):
    axC.text(yr,0.15,f"{yr}",ha="center",va="bottom",fontsize=6,color="#666")
def seg(y,x0,x1,fill,edge,lab):
    axC.add_patch(Rectangle((x0,y),x1-x0,0.42,facecolor=fill,edgecolor=edge,lw=1.0))
    axC.text((x0+x1)/2,y+0.21,lab,ha="center",va="center",fontsize=6.4)
axC.text(2005.6,2.55,"Sri Lanka",fontsize=7.4,fontweight="bold",va="center")
seg(2.15,2018,2022.9,*GREEN,"train 2018–22"); seg(2.15,2023,2025.6,*PINK,"test 2023–25")
axC.text(2005.6,1.35,"Colombia",fontsize=7.4,fontweight="bold",va="center")
seg(0.95,2006,2017.9,*GREEN,"train 2006–17"); seg(0.95,2018,2019.9,*BLUE,"val"); seg(0.95,2020,2022.6,*PINK,"test 2020–22")
axC.text(2025.7,3.0,"horizon h = 4 weeks",ha="right",va="top",fontsize=6.6,style="italic",color=INK)

# ---------- D: analysis flow ----------
axD.set_title("D  Analysis flow",loc="left",fontsize=10,fontweight="bold")
axD.set_xlim(0,10); axD.set_ylim(0,10); axD.axis("off")
def box(cx,cy,w,h,t,fill,edge,fs=6.6):
    axD.add_patch(FancyBboxPatch((cx-w/2,cy-h/2),w,h,boxstyle="round,pad=0.02,rounding_size=0.10",facecolor=fill,edgecolor=edge,lw=1.0))
    axD.text(cx,cy,t,ha="center",va="center",fontsize=fs)
def arr(a,b): axD.annotate("",xy=b,xytext=a,arrowprops=dict(arrowstyle="-|>",color="#777",lw=1.0))
box(2.3,8.7,3.8,1.1,"M1 recent-surveillance\nbaseline",*BLUE)
box(2.3,6.6,3.8,1.1,"matched no-climate\nbaseline",*GREEN)
box(7.2,6.6,3.8,1.1,"full climate model\n(M5)",*TAN)
box(4.9,4.6,5.6,1.0,"calibration / recalibration",*PINK)
box(4.9,2.9,5.6,1.0,"decision-curve net benefit",*PINK)
box(2.6,1.1,3.6,1.0,"conditional\nuncertainty",*GREY,fs=6.2)
box(7.2,1.1,3.6,1.0,"development-inclusive\nuncertainty (refit)",*GREY,fs=6.2)
arr((2.3,8.15),(2.3,7.15)); arr((2.3,8.15),(6.6,7.15)); arr((2.3,6.05),(4.6,5.1)); arr((7.2,6.05),(5.2,5.1))
arr((4.9,4.1),(4.9,3.4)); arr((4.9,2.4),(2.6,1.6)); arr((4.9,2.4),(7.2,1.6))

fig.tight_layout(pad=1.2)
fig.savefig("submission_figs/Fig1.pdf",bbox_inches="tight")
print("wrote submission_figs/Fig1.pdf (included munis=%d)"%len(inc))
