#!/usr/bin/env python3
"""Main Figure 1A — Sri Lanka RDHS analytic frame (real boundaries, not schematic).
Reads the committed 26-RDHS geometry; no invented data. Equal-area display (UTM 44N).
Writes Fig1A_srilanka_rdhs.pdf."""
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
import geopandas as g

SRC = "/home/mpcrlab/data_quarantine/geomatics/rdhs_geometry/rdhs_26_v1.gpkg"
d = g.read_file(SRC).to_crs(32644)          # UTM 44N, equal-area display for Sri Lanka
fig, ax = plt.subplots(figsize=(5.2, 7.0))
d.plot(ax=ax, facecolor="#cfe2f3", edgecolor="#33546e", linewidth=0.6)
amp = d[d["rdhs_name"].str.contains("Ampara|Kalmunai", case=False, na=False)]
if len(amp):
    amp.plot(ax=ax, facecolor="#fce5cd", edgecolor="#e69138", linewidth=0.9)
for _, r in d.iterrows():
    c = r.geometry.representative_point()
    ax.annotate(str(r["rdhs_name"])[:10], (c.x, c.y), fontsize=4.6, ha="center", va="center")
ax.set_axis_off()
ax.set_title("Sri Lanka — 26 RDHS analytic units\n(Ampara/Kalmunai split highlighted)", fontsize=9)
ax.annotate("Boundary: HDX COD-AB (Survey Dept. of Sri Lanka); CRS EPSG:32644 (UTM 44N, equal-area display)\n"
            "Ampara district split into Ampara + Kalmunai RDHS along divisional-secretariat boundaries",
            xy=(0.5, -0.04), xycoords="axes fraction", ha="center", va="top", fontsize=5.0, color="#555555")
fig.tight_layout()
fig.savefig("Fig1A_srilanka_rdhs.pdf", bbox_inches="tight")
print("wrote Fig1A_srilanka_rdhs.pdf; units:", len(d))
