# Metadata — 26-RDHS Geometry (rdhs_26_v1) — LOCAL/QUARANTINED

**File:** `~/data_quarantine/geomatics/rdhs_geometry/rdhs_26_v1.gpkg` (layer `rdhs_26`)
**SHA256:** `9e5e2c0a541ecac13f5c2aa08ca2d8fca79b36f645f9fad5c8067d74a189ee88`
**Size:** 8,683,520 bytes
**Status:** LOCAL, quarantined, git-ignored. NOT committed.
**Build date:** 2026-06-11

## Source
- HDX COD-AB Sri Lanka (Survey Department), `lka_admin_boundaries.shp.zip`
  - sha256 `505ec4a7881664f109001c672877825183c121edaf0015b4468e41e9c9ed94bf`
  - License CC BY-IGO; version v03 (valid_on 2022-08-16); CRS **EPSG:4326**.
- Layers used: `lka_admin2.shp` (25 districts), `lka_admin3.shp` (339 DS divisions).
- Build script: `~/data_quarantine/geomatics/rdhs_geometry/build_rdhs26.py`
- Crosswalks: `geomatics_templates/rdhs_crosswalk_template.csv`, `geomatics_templates/kalmunai_ampara_ds_split_template.csv`.

## Build rules
- **24 RDHS** = ADM2 districts 1:1 (district name → frozen RDHS name via crosswalk aliases: `Kilinochchi→Killinochchi`, `Monaragala→Moneragala`).
- **Kalmunai RDHS** = dissolve of **12** confirmed Kalmunai DS divisions (geometry_id `LK52K`).
- **Ampara RDHS** = dissolve of **7** confirmed Ampara DS divisions (geometry_id `LK52A`).

## Schema (GPKG layer `rdhs_26`)
`rdhs_id` (RDHS_01..RDHS_26), `rdhs_name`, `geometry_id` (ADM2 pcode for districts; LK52K/LK52A for splits), `parent_district`, `province`, `build_rule`, `n_ds` (12/7 for splits, null otherwise), `geometry` (MultiPolygon, EPSG:4326).

## QC results
| Check | Result |
|---|---|
| RDHS count | **26** ✅ |
| Unique names / duplicates | 26 unique / **0 dups** ✅ |
| Empty geometries | **0** ✅ |
| Invalid geometries (pre/post fix) | 0 / **0** ✅ |
| geometry_id nulls / unique | 0 / **26 unique** ✅ |
| CRS | **EPSG:4326** ✅ |
| Ampara RDHS + Kalmunai RDHS area | 3420.27 + 1051.29 = **4471.56 km²** vs COD-AB Ampara ADM2 **4474.66 km²** (**−0.07%**) ✅ |
| Total 26-RDHS area | **65,995.00 km²** vs ADM2 field 66,040.81 (−0.07%); equals 25-district UTM total exactly ✅ |

Areas computed in EPSG:32644 (UTM 44N). The uniform −0.07% vs the COD-AB `area_sqkm` field is a projection-method difference, not a geometry error (the dissolve conserves area exactly: 26-RDHS UTM total == 25-district UTM total).

## Change policy
Immutable build artifact. Any change (boundary re-vintage, split revision) → new versioned GPKG (`rdhs_26_v2…`) with a new checksum and metadata.
